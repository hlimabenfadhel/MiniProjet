import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { LivreService } from '../services/livre.service';
import { Livre } from '../model/livre.model';


@Component({
selector: 'app-update-livre',
templateUrl: './update-livre.component.html',
styles: []
})
export class UpdateLivreComponent implements OnInit {
currentLivre = new Livre();

  livres: Livre[] = [];
  activatedRoute: any;
  
constructor(private livreservice:LivreService,
  private router:Router,
  private livreService :LivreService)
  { }
 
 
 
  ngOnInit() {
    this.livreService.consulterLivre(this.activatedRoute.snapshot.params.id).
     subscribe( liv =>{ this.currentLivre = liv; } ) ;
    }
    
  
    updateLivre() {
      this.livreservice.updateLivre(this.currentLivre).subscribe(liv => {
      this.router.navigate(['livres']);
      },(error) => { alert("Problème lors de la modification !"); }
      );
      }
      

  

 }