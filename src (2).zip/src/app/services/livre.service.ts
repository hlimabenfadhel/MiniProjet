import { Injectable } from '@angular/core';
import { Livre } from '../model/livre.model';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
const httpOptions = {
headers: new HttpHeaders( {'Content-Type': 'application/json'} )
};
@Injectable({
providedIn: 'root'
})


export class LivreService {
  apiURL: string = 'http://localhost:8080/livres/api';
  livreService: any;
  router: any;
  constructor(private http : HttpClient) {
  }
  listeLivre(): Observable<Livre[]>{
  return this.http.get<Livre[]>(this.apiURL);
  }
  
  ajouterLivre( liv: Livre):Observable<Livre>{
    return this.http.post<Livre>(this.apiURL, liv, httpOptions);
    }

    supprimerLivre(id : number) {
      const url = `${this.apiURL}/${id}`;
     return this.http.delete(url, httpOptions);
     }

      consulterLivre(id: number): Observable<Livre> {
       const url = `${this.apiURL}/${id}`;
        return this.http.get<Livre>(url);
        }

      updateLivre(liv :Livre) : Observable<Livre>
{
return this.http.put<Livre>(this.apiURL, liv, httpOptions);
}

        
}
