export class Livre {
    idLivre : number;
    nomLivre : string;
    prixLivre : number;
    dateCreation : Date ;
    }