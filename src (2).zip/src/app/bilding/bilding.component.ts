import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bilding',
  templateUrl: './bilding.component.html',
  styles: [
  ]
})
export class BildingComponent implements OnInit {
  nom : String ="Demo";
  constructor() { }

  ngOnInit(): void {
  }

}
