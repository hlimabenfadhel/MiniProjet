package com.example.activity1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity1 extends AppCompatActivity {
TextView valeur1,valeur2,resultat,aff;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
        valeur1 = (TextView) findViewById(R.id.text1);
        valeur2 = (TextView) findViewById(R.id.textv2);
        resultat = (TextView) findViewById(R.id.resultat);
        aff = (TextView) findViewById(R.id.textView);
        valeur1.setText(getIntent().getStringExtra("val1"));
        valeur2.setText(getIntent().getStringExtra("val2"));
        String s1 = valeur1.getText().toString();
        String s2 = valeur2.getText().toString();
        resultat.setText(getIntent().getStringExtra("resultat"));
        resultat.setText(String.valueOf(Double.parseDouble(s1) + Integer.parseInt(s2)));
    }
    public void Calback(View view){
       setResult(33);
        finish();


    }
}