package com.example.activity1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity<OnActivityResult> extends AppCompatActivity {
    EditText val1;
    EditText val2;
    Button add;
    TextView resultat;
    TextView resf;
    private static final int CODE_MON_ACTIVITE=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        val1 = (EditText) findViewById(R.id.val1);
        val2 = (EditText) findViewById(R.id.val2);
        add = (Button) findViewById(R.id.addition);
        resf = (TextView) findViewById(R.id.resf);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, MainActivity1.class);
                String s1 = val1.getText().toString();
                String s2 = val2.getText().toString();
                i.putExtra("val2", val1.getText().toString());
                i.putExtra("val1", val2.getText().toString());
                startActivityForResult(i, CODE_MON_ACTIVITE);
            }

        });

    }

    void OnActivityResult()
    protected void OnActivityResult(int code_mon_activite,int resultCode,Intent data){
        super.onActivityResult(code_mon_activite,resultCode,data);
        if(code_mon_activite==CODE_MON_ACTIVITE){
          if(code_mon_activite==RESULT_OK){
     resultat.setText("resf ="+resultCode);
          }
        }


    }
}
