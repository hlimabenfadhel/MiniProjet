package com.example.tp3_ex1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText nom;
    private EditText prenom;
    private EditText age;
    private EditText site;
    private EditText tel;
    private Button bn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nom = (EditText) findViewById(R.id.nom);
        prenom = (EditText) findViewById(R.id.prenom);
        age = (EditText) findViewById(R.id.age);
        site = (EditText) findViewById(R.id.site);
        tel = (EditText) findViewById(R.id.phone);
        bn = (Button) findViewById(R.id.btn);

        bn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String s1 = nom.getText().toString();
                String s2 = prenom.getText().toString();
                String s3 = age.getText().toString();
                String s4 = site.getText().toString();
                String s5 = tel.getText().toString();
                if (s1.isEmpty()) {

                    nom.setBackgroundColor(Color.parseColor("#F44336"));
                } else {
                    nom.setBackgroundColor(Color.parseColor("#4CAF50"));
                }
                if (s2.isEmpty()) {
                    prenom.setBackgroundColor(Color.parseColor("#F44336"));

                } else {
                    prenom.setBackgroundColor(Color.parseColor("#4CAF50"));
                }
                if (s3.isEmpty()) {
                    age.setBackgroundColor(Color.parseColor("#F44336"));
                } else {
                    age.setBackgroundColor(Color.parseColor("#4CAF50"));
                }
                if (s4.isEmpty()) {

                    site.setBackgroundColor(Color.parseColor("#F44336"));
                } else {
                    site.setBackgroundColor(Color.parseColor("#4CAF50"));
                }
                if (s5.isEmpty()) {

                    tel.setBackgroundColor(Color.parseColor("#F44336"));
                } else {
                    tel.setBackgroundColor(Color.parseColor("#4CAF50"));
                }
                if(s1.isEmpty()==false && s2.isEmpty()==false && s3.isEmpty()==false && s4.isEmpty()==false && s5.isEmpty()==false) {
                    Intent in = new Intent(MainActivity.this, MainActivityA.class);
                    in.putExtra("nom", nom.getText().toString());
                    in.putExtra("prenom", prenom.getText().toString());
                    in.putExtra("age", age.getText().toString());
                    in.putExtra("sit web", site.getText().toString());
                    in.putExtra("tele", tel.getText().toString());
                    startActivity(in);
                }

            }
        });
    }
}





