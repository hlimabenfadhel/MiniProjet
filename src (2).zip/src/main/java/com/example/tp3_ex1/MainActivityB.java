package com.example.tp3_ex1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivityB extends AppCompatActivity {
    EditText telephone, url;
    Button appel, con;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_b);
        telephone = (EditText) findViewById(R.id.textc);
        appel = (Button) findViewById(R.id.btn3);
        url = (EditText) findViewById(R.id.url);
        con = (Button) findViewById(R.id.btn4);
        img = (ImageView) findViewById(R.id.image);
        telephone.setText(getIntent().getStringExtra("tele"));
        url.setText(getIntent().getStringExtra("sit web"));
    }

        public void onClick (View v){

            startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + telephone.getText().toString())));
        }

        void GoToURL (View v){

            Intent url=new Intent(Intent.ACTION_VIEW );
            url.setData( Uri.parse( "https://"+url.getText().toString() ));

            startActivity( url );

            }
        }


    }
