package com.example.tp3_ex1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.zip.Deflater;

public class MainActivityA extends AppCompatActivity {
TextView nom, prenom,age,site,tel;
Button retourner,ok;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity);
        nom=(TextView)findViewById(R.id.view1);
        prenom=(TextView)findViewById(R.id.view2);
        age=(TextView)findViewById(R.id.view3);
        site=(TextView)findViewById(R.id.view4);
        tel=(TextView)findViewById(R.id.view5);
        ok=(Button)findViewById(R.id.btn1) ;
        retourner=(Button)findViewById(R.id.btn2) ;
        nom.setText(getIntent().getStringExtra("nom"));
        prenom.setText(getIntent().getStringExtra("prenom"));
        age.setText(getIntent().getStringExtra("age"));
        site.setText(getIntent().getStringExtra("sit web"));
        tel.setText(getIntent().getStringExtra("tele"));
        retourner.setOnClickListener(new View.OnClickListener() {
            private Deflater MainActivity;

            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }


    public void Ok(View view) {
        Intent i =new Intent(MainActivityA.this,MainActivityB.class);
        i.putExtra("tele", tel.getText().toString());
        i.putExtra("sit web", site.getText().toString());
        startActivity(i);

    }


}
